# 5thSRD
This is a markdown version of the 5th Edition System Reference Document.

Documents are in the docs/ directory.

Published as a website built via mkdocs on https://5thsrd.org

# How to Build
Various indexes are built using build_indexes.py.

Build the full site using mkdocs (http://www.mkdocs.org/): mkdocs build --clean

You can also serve locally by running mkdocs serve
