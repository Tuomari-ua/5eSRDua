description: In 5th Edition (5e), classes define what a character is good at and what skills they have.

# Classes

* [Barbarian](/character/classes/barbarian/)
* [Bard](/character/classes/bard/)
* [Cleric](/character/classes/cleric/)
* [Druid](/character/classes/druid/)
* [Fighter](/character/classes/fighter/)
* [Monk](/character/classes/monk/)
* [Paladin](/character/classes/paladin/)
* [Ranger](/character/classes/ranger/)
* [Rogue](/character/classes/rogue/)
* [Sorcerer](/character/classes/sorcerer/)
* [Warlock](/character/classes/warlock/)
* [Wizard](/character/classes/wizard/)
