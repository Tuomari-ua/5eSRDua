# Character

## General Character
* [Alignment](/character/alignment/)
* [Backgrounds](/character/backgrounds/)
* [Fantasy-Historical Pantheons](/character/fantasy-historical_pantheons/)
* [Languages](/character/languages)

## Classes

* [Barbarian](/character/classes/barbarian/)
* [Bard](/character/classes/bard/)
* [Cleric](/character/classes/cleric/)
* [Druid](/character/classes/druid/)
* [Fighter](/character/classes/fighter/)
* [Monk](/character/classes/monk/)
* [Paladin](/character/classes/paladin/)
* [Ranger](/character/classes/ranger/)
* [Rogue](/character/classes/rogue/)
* [Sorcerer](/character/classes/sorcerer/)
* [Warlock](/character/classes/warlock/)
* [Wizard](/character/classes/wizard/)

## Races

* [Dragonborn](/character/races/dragonborn/)
* [Dwarf](/character/races/dwarf/)
* [Elf](/character/races/elf/)
* [Gnome](/character/races/gnome/)
* [Half-Elf](/character/races/half-elf/)
* [Half-Orc](/character/races/half-orc/)
* [Halfling](/character/races/halfling/)
* [Human](/character/races/human/)
* [Tiefling](/character/races/tiefling/)