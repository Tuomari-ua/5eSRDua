name: Helm of Comprehending Languages
type: item

# Helm of Comprehending Languages 
_Wondrous item, uncommon_ 

While wearing this helm, you can use an action to cast the **_comprehend languages_** spell from it at will. 