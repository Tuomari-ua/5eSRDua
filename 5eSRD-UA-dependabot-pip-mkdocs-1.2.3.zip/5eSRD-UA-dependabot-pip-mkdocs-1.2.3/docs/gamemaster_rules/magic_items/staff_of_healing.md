name: Staff of Healing
type: staff

# Staff of Healing 
_Staff, rare (requires attunement by a bard, cleric, or druid)_ 

This staff has 10 charges. While holding it, you can use an action to expend 1 or more of its charges to cast one of the following spells from it, using your spell save DC and spellcasting ability modifier: **_cure wounds_** (1 charge per spell level, up to 4th), **_lesser restoration_** (2 charges), or **_mass cure wounds_** (5 charges).

The staff regains 1d6 + 4 expended charges daily at dawn. If you expend the last charge, roll a d20. On a 1, the staff vanishes in a flash of light, lost forever. 