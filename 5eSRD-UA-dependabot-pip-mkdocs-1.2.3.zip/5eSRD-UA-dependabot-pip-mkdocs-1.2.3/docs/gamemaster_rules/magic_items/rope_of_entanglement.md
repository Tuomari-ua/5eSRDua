name: Rope of Entanglement
type: item

# Rope of Entanglement 
_Wondrous item, rare_ 

This rope is 30 feet long and weighs 3 pounds. If you hold one end of the rope and use an action to speak its command word, the other end darts forward to entangle a creature you can see within 20 feet of you. The target must succeed on a DC 15 Dexterity saving throw or become restrained. 