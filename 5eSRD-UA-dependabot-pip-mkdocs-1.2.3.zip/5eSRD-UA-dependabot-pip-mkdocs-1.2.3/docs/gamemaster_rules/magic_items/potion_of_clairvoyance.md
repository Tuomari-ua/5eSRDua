name: Potion of Clairvoyance
type: potion

# Potion of Clairvoyance 
_Potion, rare_ 

When you drink this potion, you gain the effect of the **_clairvoyance_** spell. An eyeball bobs in this yellowish liquid but vanishes when the potion is opened. 