name: Censer of Controlling Air Elementals
type: item

# Censer of Controlling Air Elementals 
_Wondrous item, rare_ 

While incense is burning in this censer, you can use an action to speak the censer's command word and summon an air elemental, as if you had cast the **_conjure elemental_** spell. The censer can't be used this way again until the next dawn.  

This 6-inch-wide, 1-foot-high vessel resembles a chalice with a decorated lid. It weighs 1 pound. 