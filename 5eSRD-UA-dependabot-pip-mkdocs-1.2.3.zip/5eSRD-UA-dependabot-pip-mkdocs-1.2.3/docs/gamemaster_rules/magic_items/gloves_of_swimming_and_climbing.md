name: Gloves of Swimming and Climbing
type: item

# Gloves of Swimming and Climbing 
_Wondrous item, uncommon (requires attunement)_ 

While wearing these gloves, climbing and swimming don't cost you extra movement, and you gain a +5 bonus to Strength (Athletics) checks made to climb or swim.