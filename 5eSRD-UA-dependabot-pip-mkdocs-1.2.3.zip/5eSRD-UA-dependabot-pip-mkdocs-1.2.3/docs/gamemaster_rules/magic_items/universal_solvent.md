name: Universal Solvent
type: item

# Universal Solvent 
_Wondrous item, legendary_ 

This tube holds milky liquid with a strong alcohol smell. You can use an action to pour the contents of the tube onto a surface within reach. The liquid instantly dissolves up to 1 square foot of adhesive it touches, including **sovereign glue**.