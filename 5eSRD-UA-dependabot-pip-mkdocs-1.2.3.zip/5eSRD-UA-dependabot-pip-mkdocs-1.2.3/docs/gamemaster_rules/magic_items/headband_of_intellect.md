name: Headband of Intellect
type: item

# Headband of Intellect 
_Wondrous item, uncommon (requires attunement)_ 

Your Intelligence score is 19 while you wear this headband. It has no effect on you if your Intelligence is already 19 or higher. 