name: Vicious Weapon
type: weapon

# Vicious Weapon 
_Weapon (any), rare_ 

When you roll a 20 on your attack roll with this magic weapon, your critical hit deals an extra 2d6 damage of the weapon's type. 