name: Amulet of Proof against Detection and Location
type: item

# Amulet of Proof against Detection and Location 
_Wondrous item, uncommon (requires attunement)_ 

While wearing this amulet, you are hidden from divination magic. You can't be targeted by such magic or perceived through magical scrying sensors.