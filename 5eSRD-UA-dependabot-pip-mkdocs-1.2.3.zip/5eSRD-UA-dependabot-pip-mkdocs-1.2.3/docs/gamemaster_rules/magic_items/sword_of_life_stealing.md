name: Sword of Life Stealing
type: weapon

# Sword of Life Stealing 
_Weapon (any sword), rare (requires attunement)_ 

When you attack a creature with this magic weapon and roll a 20 on the attack roll, that target takes an extra 3d6 necrotic damage, provided that the target isn't a construct or an undead. You gain temporary hit points equal to the extra damage dealt. 
