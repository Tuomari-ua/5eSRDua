name: Medallion of Thoughts
type: item

# Medallion of Thoughts 
_Wondrous item, uncommon (requires attunement)_ 

The medallion has 3 charges. While wearing it, you can use an action and expend 1 charge to cast the **_detect thoughts_** spell (save DC 13) from it. The medallion regains 1d3 expended charges daily at dawn. 