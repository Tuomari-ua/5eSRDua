name: Trident of Fish Command
type: weapon

# Trident of Fish Command 
_Weapon (trident), uncommon (requires attunement)_ 

This trident is a magic weapon. It has 3 charges. While you carry it, you can use an action and expend 1 charge to cast **_dominate beast_** (save DC 15) from it on a beast that has an innate swimming speed. The trident regains 1d3 expended charges daily at dawn.