name: Ring of Regeneration
type: ring

# Ring of Regeneration 
_Ring, very rare (requires attunement)_ 

While wearing this ring, you regain 1d6 hit points every 10 minutes, provided that you have at least 1 hit point. If you lose a body part, the ring causes the missing part to regrow and return to full functionality after 1d6 + 1 days if you have at least 1 hit point the whole time. 