name: Mantle of Spell Resistance
type: item

# Mantle of Spell Resistance 
_Wondrous item, rare (requires attunement)_ 

You have advantage on saving throws against spells while you wear this cloak. 