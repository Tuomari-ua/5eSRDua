name: Ring of Spell Turning
type: ring

# Ring of Spell Turning 
_Ring, legendary (requires attunement)_ 

While wearing this ring, you have advantage on saving throws against any spell that targets only you (not in an area of effect). In addition, if you roll a 20 for the save and the spell is 7th level or lower, the spell has no effect on you and instead targets the caster, using the slot level, spell save DC, attack bonus, and spellcasting ability of the caster. 