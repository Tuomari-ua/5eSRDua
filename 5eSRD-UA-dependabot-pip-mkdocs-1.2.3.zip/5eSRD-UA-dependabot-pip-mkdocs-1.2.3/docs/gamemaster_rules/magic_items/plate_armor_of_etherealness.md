name: Plate Armor of Etherealness
type: armor

# Plate Armor of Etherealness 
_Armor (plate), legendary (requires attunement)_ 

While you're wearing this armor, you can speak its command word as an action to gain the effect of the **_etherealness_** spell, which last for 10 minutes or until you remove the armor or use an action to speak the command word again. This property of the armor can't be used again until the next dawn. 
