name: Potion of Invisibility
type: potion

# Potion of Invisibility 
_Potion, very rare_ 

This potion's container looks empty but feels as though it holds liquid. When you drink it, you become invisible for 1 hour. Anything you wear or carry is invisible with you. The effect ends early if you attack or cast a spell. 