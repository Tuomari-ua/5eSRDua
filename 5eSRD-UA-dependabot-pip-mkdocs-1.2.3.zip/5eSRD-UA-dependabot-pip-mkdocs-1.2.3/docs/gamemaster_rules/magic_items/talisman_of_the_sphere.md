name: Talisman of the Sphere
type: item

# Talisman of the Sphere 
_Wondrous item, legendary (requires attunement)_ 

When you make an Intelligence (Arcana) check to control a **sphere of annihilation** while you are holding this talisman, you double your proficiency bonus on the check. In addition, when you start your turn with control over a **sphere of annihilation**, you can use an action to levitate it 10 feet plus a number of additional feet equal to 10 × your Intelligence modifier. 