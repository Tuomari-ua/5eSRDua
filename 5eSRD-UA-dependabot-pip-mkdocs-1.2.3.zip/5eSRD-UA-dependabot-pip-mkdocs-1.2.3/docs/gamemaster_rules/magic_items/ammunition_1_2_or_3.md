name: Ammunition, +1, +2 or +3
type: weapon

# Ammunition, +1, +2, or +3 
_Weapon (any ammunition), uncommon (+1), rare (+2), or very rare (+3)_ 

You have a bonus to attack and damage rolls made with this piece of magic ammunition. The bonus is determined by the rarity of the ammunition. Once it hits a target, the ammunition is no longer magical. 