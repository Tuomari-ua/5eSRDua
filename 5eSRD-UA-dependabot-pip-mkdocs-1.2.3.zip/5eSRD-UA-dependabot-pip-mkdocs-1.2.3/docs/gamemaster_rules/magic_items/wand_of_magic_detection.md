name: Wand of Magic Detection
type: wand

# Wand of Magic Detection 
_Wand, uncommon_ 

This wand has 3 charges. While holding it, you can expend 1 charge as an action to cast the **_detect magic_** spell from it. The wand regains 1d3 expended charges daily at dawn. 