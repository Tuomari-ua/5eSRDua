name: Elven Chain
type: armor

# Elven Chain 
_Armor (chain shirt), rare_ 

You gain a +1 bonus to AC while you wear this armor. You are considered proficient with this armor even if you lack proficiency with medium armor. 