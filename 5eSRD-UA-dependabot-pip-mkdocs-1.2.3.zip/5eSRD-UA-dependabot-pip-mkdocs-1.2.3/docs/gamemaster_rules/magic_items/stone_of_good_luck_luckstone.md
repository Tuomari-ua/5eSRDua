name: Stone of Good Luck (Luckstone)
type: item

# Stone of Good Luck (Luckstone) 
_Wondrous item, uncommon (requires attunement)_ 

While this polished agate is on your person, you gain a +1 bonus to ability checks and saving throws. 