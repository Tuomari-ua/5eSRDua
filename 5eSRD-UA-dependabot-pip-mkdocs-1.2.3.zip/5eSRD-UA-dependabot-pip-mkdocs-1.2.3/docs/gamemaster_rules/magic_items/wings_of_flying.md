name: Wings of Flying
type: item

# Wings of Flying 
_Wondrous item, rare (requires attunement)_ 

While wearing this cloak, you can use an action to speak its command word. This turns the cloak into a pair of bat wings or bird wings on your back for 1 hour or until you repeat the command word as an action. The wings give you a flying speed of 60 feet. When they disappear, you can't use them again for 1d12 hours.