name: Weapon, +1, +2, or +3
type: weapon

# Weapon, +1, +2, or +3 
_Weapon (any), uncommon (+1), rare (+2), or very rare (+3)_ 

You have a bonus to attack and damage rolls made with this magic weapon. The bonus is determined by the weapon's rarity. 