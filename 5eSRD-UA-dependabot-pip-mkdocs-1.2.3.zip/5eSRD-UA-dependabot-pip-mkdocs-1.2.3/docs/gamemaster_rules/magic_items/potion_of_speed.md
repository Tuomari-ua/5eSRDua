name: Potion of Speed
type: potion

# Potion of Speed 
_Potion, very rare_ 

When you drink this potion, you gain the effect of the **_haste_** spell for 1 minute (no concentration required). The potion's yellow fluid is streaked with black and swirls on its own. 