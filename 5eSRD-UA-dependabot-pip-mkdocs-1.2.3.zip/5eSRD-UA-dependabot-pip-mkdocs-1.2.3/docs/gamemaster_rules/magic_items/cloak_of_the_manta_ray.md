name: Cloak of the Manta Ray
type: item

# Cloak of the Manta Ray 
_Wondrous item, uncommon_ 

While wearing this cloak with its hood up, you can breathe underwater, and you have a swimming speed of 60 feet. Pulling the hood up or down requires an action. 
