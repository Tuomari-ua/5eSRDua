name: Pearl of Power
type: item

# Pearl of Power 
_Wondrous item, uncommon (requires attunement by a spellcaster)_ 

While this pearl is on your person, you can use an action to speak its command word and regain one expended spell slot. If the expended slot was of 4th level or higher, the new slot is 3rd level. Once you use the pearl, it can􀁠t be used again until the next dawn. 
