name: Stone of Controlling Earth Elementals
type: item

# Stone of Controlling Earth Elementals 
_Wondrous item, rare_ 

If the stone is touching the ground, you can use an action to speak its command word and summon an earth elemental, as if you had cast the **_conjure elemental_** spell. The stone can't be used this way again until the next dawn. The stone weighs 5 pounds. 