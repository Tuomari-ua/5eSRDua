name: Mace of Disruption
type: weapon

# Mace of Disruption 
_Weapon (mace), rare (requires attunement)_ 

When you hit a fiend or an undead with this magic weapon, that creature takes an extra 2d6 radiant damage. If the target has 25 hit points or fewer after taking this damage, it must succeed on a DC 15 Wisdom saving throw or be destroyed. On a successful save, the creature becomes frightened of you until the end of your next turn.

While you hold this weapon, it sheds bright light in a 20-foot radius and dim light for an additional 20 feet. 