name: Tome of Clear Thought
type: item

# Tome of Clear Thought 
_Wondrous item, very rare_ 

This book contains memory and logic exercises, and its words are charged with magic. If you spend 48 hours over a period of 6 days or fewer studying the book's contents and practicing its guidelines, your Intelligence score increases by 2, as does your maximum for that score. The manual then loses its magic, but regains it in a century. 