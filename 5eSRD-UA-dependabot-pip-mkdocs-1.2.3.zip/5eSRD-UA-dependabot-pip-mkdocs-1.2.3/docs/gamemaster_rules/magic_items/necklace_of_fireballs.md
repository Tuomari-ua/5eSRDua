name: Necklace of Fireballs
type: item

# Necklace of Fireballs 
_Wondrous item, rare_ 

This necklace has 1d6 + 3 beads hanging from it. You can use an action to detach a bead and throw it up to 60 feet away. When it reaches the end of its trajectory, the bead detonates as a 3rd-level **_fireball_** spell (save DC 15).

You can hurl multiple beads, or even the whole necklace, as one action. When you do so, increase the level of the **_fireball_** by 1 for each bead beyond the first.