name: Cloak of Protection
type: item

# Cloak of Protection 
_Wondrous item, uncommon (requires attunement)_ 

You gain a +1 bonus to AC and saving throws while you wear this cloak. 