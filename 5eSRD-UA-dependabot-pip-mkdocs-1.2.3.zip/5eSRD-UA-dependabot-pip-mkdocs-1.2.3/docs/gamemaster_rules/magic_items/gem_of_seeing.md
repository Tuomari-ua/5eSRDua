name: Gem of Seeing
type: item

# Gem of Seeing 
_Wondrous item, rare (requires attunement)_ 

This gem has 3 charges. As an action, you can speak the gem's command word and expend 1 charge. For the next 10 minutes, you have truesight out to 120 feet when you peer through the gem.

The gem regains 1d3 expended charges daily at dawn. 