name: Wand of Secrets
type: wand

# Wand of Secrets 
_Wand, uncommon_ 

The wand has 3 charges. While holding it, you can use an action to expend 1 of its charges, and if a secret door or trap is within 30 feet of you, the wand pulses and points at the one nearest to you. The wand regains 1d3 expended charges daily at dawn. 
