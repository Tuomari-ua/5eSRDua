name: Slippers of Spider Climbing
type: item

# Slippers of Spider Climbing 
_Wondrous item, uncommon (requires attunement)_ 

While you wear these light shoes, you can move up, down, and across vertical surfaces and upside down along ceilings, while leaving your hands free. You have a climbing speed equal to your walking speed. However, the slippers don't allow you to move this way on a slippery surface, such as one covered by ice or oil. 