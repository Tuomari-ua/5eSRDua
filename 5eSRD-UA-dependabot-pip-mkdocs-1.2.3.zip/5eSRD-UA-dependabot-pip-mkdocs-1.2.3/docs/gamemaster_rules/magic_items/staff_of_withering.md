name: Staff of Withering
type: staff

# Staff of Withering 
_Staff, rare (requires attunement by a cleric, druid, or warlock)_ 

This staff has 3 charges and regains 1d3 expended charges daily at dawn.

The staff can be wielded as a magic quarterstaff. On a hit, it deals damage as a normal quarterstaff, and you can expend 1 charge to deal an extra 2d10 necrotic damage to the target. In addition, the target must succeed on a DC 15 Constitution saving throw or have disadvantage for 1 hour on any ability check or saving throw that uses Strength or Constitution. 