name: Ring of Protection
type: ring

# Ring of Protection 
_Ring, rare (requires attunement)_ 

You gain a +1 bonus to AC and saving throws while wearing this ring. 