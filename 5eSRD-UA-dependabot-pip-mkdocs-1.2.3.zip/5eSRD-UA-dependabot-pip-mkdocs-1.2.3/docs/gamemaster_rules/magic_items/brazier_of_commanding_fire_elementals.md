name: Brazier of Commanding Fire Elementals
type: item

# Brazier of Commanding Fire Elementals 
_Wondrous item, rare_ 

While a fire burns in this brass brazier, you can use an action to speak the brazier's command word and summon a fire elemental, as if you had cast the **_conjure elemental_** spell. The brazier can't be used this way again until the next dawn. The brazier weighs 5 pounds. 