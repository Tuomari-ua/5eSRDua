name: Amulet of Health
type: item

# Amulet of Health 
_Wondrous item, rare (requires attunement)_ 

Your Constitution score is 19 while you wear this amulet. It has no effect on you if your Constitution is already 19 or higher. 