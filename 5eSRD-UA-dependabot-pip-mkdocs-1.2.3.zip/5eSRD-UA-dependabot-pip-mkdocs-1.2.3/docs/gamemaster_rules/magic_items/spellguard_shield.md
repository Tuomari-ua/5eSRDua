name: Spellguard Shield
type: armor

# Spellguard Shield 
_Armor (shield), very rare (requires attunement)_ 

While holding this shield, you have advantage on saving throws against spells and other magical effects, and spell attacks have disadvantage against you. 