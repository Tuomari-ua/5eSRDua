name: Wind Fan
type: item

# Wind Fan 
_Wondrous item, uncommon_ 

While holding this fan, you can use an action to cast the **_gust of wind_** spell (save DC 13) from it. Once used, the fan shouldn't be used again until the next dawn. Each time it is used again before then, it has a cumulative 20 percent chance of not working and tearing into useless, nonmagical tatters. 