name: Brooch of Shielding
type: item

# Brooch of Shielding 
_Wondrous item, uncommon (requires attunement)_ 

While wearing this brooch, you have resistance to force damage, and you have immunity to damage from the **_magic missile_** spell. 