name: Helm of Teleportation
type: item

# Helm of Teleportation 
_Wondrous item, rare (requires attunement)_ 

This helm has 3 charges. While wearing it, you can use an action and expend 1 charge to cast the **_teleport_** spell from it. The helm regains 1d3 expended charges daily at dawn. 