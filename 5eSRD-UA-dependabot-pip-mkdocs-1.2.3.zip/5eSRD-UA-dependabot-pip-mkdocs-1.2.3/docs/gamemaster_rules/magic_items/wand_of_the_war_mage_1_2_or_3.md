name: Wand of the War Mage, +1, +2, or +3
type: wand

# Wand of the War Mage, +1, +2, or +3 
_Wand, uncommon (+1), rare (+2), or very rare (+3) (requires attunement by a spellcaster)_ 

While holding this wand, you gain a bonus to spell attack rolls determined by the wand's rarity. In addition, you ignore half cover when making a spell attack. 