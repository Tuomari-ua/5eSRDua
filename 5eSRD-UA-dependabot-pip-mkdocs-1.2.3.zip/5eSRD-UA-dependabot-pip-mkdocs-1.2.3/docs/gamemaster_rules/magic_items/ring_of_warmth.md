name: Ring of Warmth
type: ring

# Ring of Warmth 
_Ring, uncommon (requires attunement)_ 

While wearing this ring, you have resistance to cold damage. In addition, you and everything you wear and carry are unharmed by temperatures as low as −50 degrees Fahrenheit. 