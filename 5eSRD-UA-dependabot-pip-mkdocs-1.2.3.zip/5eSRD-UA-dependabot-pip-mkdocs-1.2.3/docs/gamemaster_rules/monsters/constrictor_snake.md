name: Constrictor Snake
type: beast
cr: .25

# Constrictor Snake 
_Large beast, unaligned_

**Armor Class** 12    
**Hit Points** 13 (2d10 + 2)    
**Speed** 30 ft., swim 30 ft. 

| STR     | DEX     | CON     | INT     | WIS     | CHA     |
|---------|---------|---------|---------|---------|---------|
| 15 (+2) | 14 (+2) | 12 (+1) | 1 (−5)  | 10 (+0) | 3 (−4)  |   

**Senses** blindsight 10 ft., passive Perception 10    
**Languages** --    
**Challenge** 1/4 (50 XP) 

### Actions    
**Bite.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one creature. _Hit:_ 5 (1d6 + 2) piercing damage.    
**Constrict.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one creature. _Hit:_ 6 (1d8 + 2) bludgeoning damage, and the target is grappled (escape DC 14). Until this grapple ends, the creature is restrained, and the snake can't constrict another target. 