name: Commoner
type: humanoid (any race)
cr: 0

# Commoner 
_Medium humanoid (any race), any alignment_

**Armor Class** 10    
**Hit Points** 4 (1d8)    
**Speed** 30 ft. 

| STR     | DEX     | CON     | INT     | WIS     | CHA     |
|---------|---------|---------|---------|---------|---------|
| 10 (+0) | 10 (+0) | 10 (+0) | 10 (+0) | 10 (+0) | 10 (+0) |   

**Senses** passive Perception 10    
**Languages** any one language (usually Common)    
**Challenge** 0 (10 XP) 

### Actions 
**Club.** _Melee Weapon Attack:_ +2 to hit, reach 5 ft., one target. _Hit:_ 2 (1d4) bludgeoning damage. 

### Description
Commoners include peasants, serfs, slaves, servants, pilgrims, merchants, artisans, and hermits. 