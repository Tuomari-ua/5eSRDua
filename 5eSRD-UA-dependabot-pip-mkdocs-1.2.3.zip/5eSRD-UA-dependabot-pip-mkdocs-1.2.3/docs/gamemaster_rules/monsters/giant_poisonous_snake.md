name: Giant Poisonous Snake
type: beast
cr: .25

# Giant Poisonous Snake 
_Medium beast, unaligned_

**Armor Class** 14    
**Hit Points** 11 (2d8 + 2)    
**Speed** 30 ft., swim 30 ft. 

| STR     | DEX     | CON     | INT     | WIS     | CHA     |
|---------|---------|---------|---------|---------|---------|
| 10 (+0) | 18 (+4) | 13 (+1) | 2 (−4)  | 10 (+0) | 3 (−4)  |  

**Skills** Perception +2    
**Senses** blindsight 10 ft., passive Perception 12    
**Languages** --    
**Challenge** 1/4 (50 XP) 

### Actions    
**Bite.** _Melee Weapon Attack:_ +6 to hit, reach 10 ft., one target. _Hit:_ 6 (1d4 + 4) piercing damage, and the target must make a DC 11 Constitution saving throw, taking 10 (3d6) poison damage on a failed save, or half as much damage on a successful one. 