# Equipment

* [Adventuring Gear](/adventuring/equipment/adventuring_gear/)      
* [Armor](/adventuring/equipment/armor/)                            
* [Coins](/adventuring/equipment/coins/)                            
* [Equipment Packs](/adventuring/equipment/equipment_packs/)        
* [Mounts and Vehicles](/adventuring/equipment/mounts_and_vehicles/)
* [Tools](/adventuring/equipment/tools/)                            
* [Trade Goods](/adventuring/equipment/trade_goods/)                
* [Weapons](/adventuring/equipment/weapons/)     